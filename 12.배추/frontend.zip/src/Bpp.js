import "./App.css"
function Bpp() {
    let a = "";
    if (a === '') {
        a = 'Hello Bpp'
    }
    return (
        <div className="App">
            <p>{a}</p>
        </div>
    );
}
export default Bpp;